library(tidyverse)
library(rjags)
library(ggmcmc)
library(polspline)

#################################################
## load data
## gives us:
#### d1 & d2 -> an 8x8 matrix of distances each
#### y -> an 8x40 matrix of responses
#### a -> vector of category membership
#### n -> number of ???? (=8)
#### nstim -> number of stimuli (=8)
#### nsubj -> number of subjects (=8)
#################################################

load("KruschkeData.Rdata")

#################################################
## prepare data
#################################################

x <- y
y <- rowSums(x) # successful identifications per category
t <- n * nsubj  # number of trials
dataList <- list(y=y, nstim=nstim, t=t, a=a, d1=d1, d2=d2,
                 betaParameter = 50000)

#################################################
## define model script
#################################################

modelFile = "GCM_5_supermodels.txt"

#################################################
## funtion to run JAGS & retrieve samples
## depending on betaParameter for w
#################################################


# set up and run model
jagsModel = jags.model(file = modelFile, 
                       data = dataList,
                       n.chains = 2)
update(jagsModel, n.iter = 10000)
codaSamples = coda.samples(jagsModel, 
                           variable.names = c("alpha"),
                           n.iter = 40000)
ms = ggs(codaSamples)
ggs_histogram(ms)
ggs_density(ms)

#################################################
## Bayes Factor
#################################################

get_BF = function(alpha) {
  nll = Vectorize(function(c) {
    - sum(log(2*(1-c) * alpha + c))
  })
  c = optim(par = list(c = 0.1), fn = nll, lower = 0.000001, method = "L-BFGS-B")$par
  # c = density(alpha, from = 0, to = 1)$y[1]
  (2-c)/c
}

paste0("Bayes factor in favor of flat prior model: ", round(get_BF(filter(ggs(codaSamples), Parameter == "alpha")$value) ,3)) %>% show



