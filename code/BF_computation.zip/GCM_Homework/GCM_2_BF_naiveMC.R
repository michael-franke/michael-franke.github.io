library(tidyverse)
library(rjags)
library(ggmcmc)
library(polspline)

#################################################
## load data
## gives us:
#### d1 & d2 -> an 8x8 matrix of distances each
#### y -> an 8x40 matrix of responses
#### a -> vector of category membership
#### n -> number of ???? (=8)
#### nstim -> number of stimuli (=8)
#### nsubj -> number of subjects (=8)
#################################################

load("KruschkeData.Rdata")

#################################################
## prepare data
#################################################

x <- y
y <- rowSums(x) # successful identifications per category
t <- n * nsubj  # number of trials
dataList <- list(y=y, nstim=nstim, t=t, a=a, d1=d1, d2=d2)

#################################################
## define model script
#################################################

modelFile = "GCM_2_BF_naiveMC.txt"

#################################################
## funtion to run JAGS & retrieve samples
## depending on betaParameter for w
#################################################

nSamples = 150000

sample_likelihoods = function(betaParameter){
  # fix betaParameter for prior of w
  dataList$betaParameter = betaParameter
  # set up and run model
  jagsModel = jags.model(file = modelFile, 
                         data = dataList,
                         n.chains = 2)
  update(jagsModel, n.iter = 15000)
  codaSamples = coda.samples(jagsModel, 
                             variable.names = c("lh"),
                             n.iter = nSamples)
  # returns the sampled log likelihood values
  filter(ggs(codaSamples), Parameter == "lh")$value
}


#################################################
## compute evidence
#################################################

samples_complex = sample_likelihoods(betaParameter = 1)
samples_simple  = sample_likelihoods(betaParameter = 50000)
marg_lh_complex   = samples_complex %>% exp %>% mean 
marg_lh_simple    = samples_simple  %>% exp %>% mean 
 
paste0("Bayes factor in favor of flat prior model: ", round(marg_lh_complex/marg_lh_simple ,3)) %>% show

#################################################
## plot time course
#################################################

BFVec = sapply(seq(10000,nSamples, by = 200), 
               function(i) samples_complex[1:i] %>% exp %>% mean / 
                           samples_simple[1:i]  %>% exp %>% mean)
ggplot(data.frame(i = seq(10000,nSamples, by = 200), BF = BFVec), aes(x=i, y=BF)) +
  geom_line() + geom_hline(yintercept = 4.3, color = "firebrick") + 
  xlab("number of samples") + ylab('approximate Bayes factor')

